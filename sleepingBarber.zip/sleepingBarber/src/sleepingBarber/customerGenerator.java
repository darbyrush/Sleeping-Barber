package sleepingBarber;
//Darby Rush
	//010763432
	//Operating systems



	import java.util.Random;
	import java.util.*;


	public class customerGenerator implements Runnable{
	    barberShop shop;
	    customer customer;
	    Thread thread;
	    long customerID;
	    Random rand = new Random();
	    Date date = new Date();
	    
	    public customerGenerator(barberShop shop) {
	        this.shop = shop;
	    }

	    public void run() {

	        while (true) {
	            customer = new customer(shop);
	            thread = new Thread(customer);
	            customerID = thread.getId();
	            customer.setName(customerID);
	            System.out.println("Customer: " + customerID + " entering the shop at " + date);
	            thread.start();
	            try {
	                Thread.sleep(rand.nextInt(5000)+1);
	            } catch (InterruptedException e) {
	                System.out.println("Error :-(");
	            }
	        }
	    }

	    public long getID() {
	        return customerID;
	    }
	}