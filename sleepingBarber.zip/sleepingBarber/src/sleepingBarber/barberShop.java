package sleepingBarber;

//Darby Rush
//010763432
//Operating systems

import java.util.concurrent.Semaphore;
import java.util.*;

public class barberShop {
  Semaphore customersReady = new Semaphore(0);
  Semaphore barberReady = new Semaphore(0);
  Semaphore mutex = new Semaphore(1);
  int waiting = 0;
  int nChairs;
  long customerID;
  Random rand = new Random();
  LinkedList<customer> customerList;

  public barberShop(int availableSeats) {
      this.nChairs = availableSeats;
      customerList = new LinkedList<customer>();
  }

  public void cutHair() {
      customer customer;
      try {
          if (waiting == 0) {
              System.out.println("There is no customers in the waiting room.");
              this.barberGoToSleep();
              System.out.println("Barber started...");
          }
          customersReady.acquire();
          mutex.acquire();
          customer = (customer)((LinkedList<?>)customerList).poll();
          System.out.println("Barber found a customer in the waiting room.");
          System.out.println("Cutting hair of Customer: " + customer.getName());
          Thread.sleep(sleepingBarber.sleepTime * 100);   //simulating cutting hair time
          System.out.println("Finished cutting hair of Customer " + customer.getName());
          barberReady.release();
          waiting = waiting - 1;
          mutex.release();
      } catch (InterruptedException e) {
          System.out.println("Error :-(");
      } 
  }

  public void barberGoToSleep() {
      try {
          Thread.sleep(sleepingBarber.sleepTime * 100);
      } catch (Exception e) {
          System.out.println("Error :-(");
      }
  }

  public void add(customer customer) {
      try {
          if (nChairs > waiting) {
              mutex.acquire();
              waiting = waiting + 1;
              customerID = customer.getName();
              customerList.addLast(customer);
              System.out.println("Customer " + customer.getName() + " got a chair");
              System.out.println("People in waiting room: " + waiting);
              customersReady.release();
              customerID = customer.getName();
              mutex.release();
              barberReady.acquire();
          } else {
              System.out.println("No chair available for customer: " + customer.getName());
              System.out.println("Customer: " + customer.getName() + " Leaves");
          }
      } catch (Exception e) {
          System.out.println("Error :-(");
      }
  }
}
