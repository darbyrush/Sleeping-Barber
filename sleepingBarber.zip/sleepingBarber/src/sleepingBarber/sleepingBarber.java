package sleepingBarber;

//Darby Rush
//010763432
//Operating systems

public class sleepingBarber {

  static int sleepTime;
  static int availableSeats;
  public static void main(String[] args) {

      
      arguments receive = new arguments(args);
      receive.parseArguments();
      sleepTime = receive.getSleepTime();
      availableSeats = receive.getAvailableSeats();
      System.out.println("Sleeping time is " + sleepTime + ", " + "Available seats is " + availableSeats);
       
      System.out.println("How long the barber sleeps = " + sleepTime);
      System.out.println("Number of chairs in waiting room = " + availableSeats);
      System.out.println("\n");
      barberShop shop = new barberShop(availableSeats);
      Barber barber = new Barber(shop);
      customerGenerator custGen = new customerGenerator(shop);
      Thread oneBarber = new Thread(barber);
      Thread multipleCustGen = new Thread(custGen);
      oneBarber.start();
      multipleCustGen.start();
  }
}