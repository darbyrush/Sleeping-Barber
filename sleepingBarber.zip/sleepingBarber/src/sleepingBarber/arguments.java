package sleepingBarber;

public class arguments {
    
    int sleepTime;
    int availableSeats;
    String[] arguments;

    arguments(String[] args) {
        this.arguments = args;
    }

    public void parseArguments() {
    	
        if (this.arguments.length > 0) {
            try {
                this.sleepTime = Integer.parseInt(arguments[0]);
                this.availableSeats = Integer.parseInt(arguments[1]);
            } catch (NumberFormatException e) {
                System.out.println("This Input will Not work!");
                System.exit(1);
            }
        }
    }

    public int getSleepTime() {
        return this.sleepTime;
    }

    public int getAvailableSeats() {
        return this.availableSeats;
    }
}

