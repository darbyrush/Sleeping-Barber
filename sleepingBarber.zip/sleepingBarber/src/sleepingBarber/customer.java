//Darby Rush
//ID: Darby Rush

package sleepingBarber;



//customer object that will become thread.
public class customer implements Runnable{
  barberShop shop;
  long customerName;
  
  public customer(barberShop shop) {
      this.shop = shop;
  }

  public long getName() {
      return this.customerName;
  }

  public void setName(long customerName) {
      this.customerName = customerName;
  }

  //increase: release()
  //decrease: acquire()

  public void run() {
      try {
          goForHairCut();
      } catch (Exception e) {
          System.out.println(" ");
      }
  }

  private void goForHairCut() {
      shop.add(this);
  }
}


