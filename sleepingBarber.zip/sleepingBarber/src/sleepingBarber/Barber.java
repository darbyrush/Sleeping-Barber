package sleepingBarber;

//Darby Rush
//010763432
//Operating systems

public class Barber implements Runnable {
    barberShop shop;


    public Barber(barberShop shop) {
        this.shop = shop;
    }

    public void run() {
        while (true) {
            try {
                Thread.sleep(sleepingBarber.sleepTime * 1000);
                System.out.println("Barber is wating for customer.");
                System.out.println("Barber waiting for lock.");
                shop.cutHair();
            } catch (Exception e) {
                System.out.println("Error :-{");
            }
        }
    }
}